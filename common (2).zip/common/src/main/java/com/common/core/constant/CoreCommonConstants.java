package com.common.core.constant;

public class CoreCommonConstants {
  public static final String HEADERS_CONTEXT_NAME = "httpHeaders";
  public static final String REQUEST_CONTEXT_NAME = "core-request-context";
}
