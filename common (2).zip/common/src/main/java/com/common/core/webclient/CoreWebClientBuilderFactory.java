package com.common.core.webclient;

import com.common.core.enums.CoreWebClientBuilderType;
import org.springframework.web.reactive.function.client.WebClient;

public interface CoreWebClientBuilderFactory {
  public WebClient.Builder getWebClientBuilder(CoreWebClientBuilderType webClientType);
}
