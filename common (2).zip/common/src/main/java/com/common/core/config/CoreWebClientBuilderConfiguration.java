package com.common.core.config;

import com.common.core.constant.CoreWebClientBuilderTypeConstants;
import com.common.core.model.CoreWebClientConnectionProperties;
import com.common.core.model.CoreWebClientProperties;
import com.common.core.webclient.filters.CoreHeaderExchange;
import com.common.core.webclient.filters.CoreRequestContextToQueryParamExchange;
import com.common.core.webclient.filters.CoreWebClientRequestResponseLogger;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import io.netty.util.CharsetUtil;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.util.concurrent.TimeUnit;

@Configuration
public class CoreWebClientBuilderConfiguration {

  private final CoreWebClientConnectionProperties coreWebClientConnectionProperties;

  @Value("${ulta.webclient.config.writetimeout:10000}")
  private Integer writeTimeoutInMilliSec;

  @Value("${ulta.webclient.config.readtimeout:10000}")
  private Integer readTimeoutInMilliSec;

  @Value("${ulta.webclient.config.loggingresponse.enabled:false}")
  private boolean loggingEnabled;

  @Value("${ulta.webclient.maxConnections:-1}")
  private Integer maxConnections;

  public CoreWebClientBuilderConfiguration(
      CoreWebClientConnectionProperties coreWebClientConnectionProperties) {
    this.coreWebClientConnectionProperties = coreWebClientConnectionProperties;
  }

  public CoreWebClientProperties createDefaultWebClientConfig() {
    CoreWebClientProperties coreWebClientProperties = new CoreWebClientProperties();
    coreWebClientProperties.setCompressionEnabled(false);
    coreWebClientProperties.setConnectionPoolName("ulta-webclient-conn-pool");
    coreWebClientProperties.setMaxConnectionPoolSize(this.maxConnections);
    coreWebClientProperties.setReadTimeoutMilli(this.readTimeoutInMilliSec);
    coreWebClientProperties.setWriteTimeoutMilli(this.writeTimeoutInMilliSec);
    coreWebClientProperties.setLoggingEnabled(this.loggingEnabled);
    return coreWebClientProperties;
  }

  @Bean(name = "defaultWebClientConfig")
  public String defaultWebClientConfig() {
    return "defaultWebClientConfig";
  }

  @Bean(CoreWebClientBuilderTypeConstants.CORE_WEB_CLIENT_BUILDER)
  @Scope("prototype")
  public WebClient.Builder createCoreBuilder(
      @Qualifier("defaultWebClientConfig") String webClientConfigName) {
    return createDefaultBuilder(getWebClientConfigProperties(webClientConfigName))
        .filter(new CoreHeaderExchange())
        .filter(new CoreRequestContextToQueryParamExchange());
  }

  @Bean(CoreWebClientBuilderTypeConstants.ORCH_WEB_CLIENT_BUILDER)
  @Scope("prototype")
  public WebClient.Builder createOrchestrationBuilder(
      @Qualifier("defaultWebClientConfig") String webClientConfigName) {
    return createDefaultBuilder(getWebClientConfigProperties(webClientConfigName))
        .filter(new CoreHeaderExchange());
  }

  @Bean(CoreWebClientBuilderTypeConstants.ORCH_WITH_COMPRESSION_WEB_CLIENT_BUILDER)
  @Scope("prototype")
  public WebClient.Builder createOrchestrationWithCompressionBuilder(
      @Qualifier("defaultWebClientConfig") String webClientConfigName) {
    CoreWebClientProperties defaultWebClientConfig =
        getWebClientConfigProperties(webClientConfigName);
    defaultWebClientConfig.setCompressionEnabled(true);
    return createDefaultBuilder(defaultWebClientConfig).filter(new CoreHeaderExchange());
  }

  @Bean(CoreWebClientBuilderTypeConstants.EXTERNAL_WEB_CLIENT_BUILDER)
  @Scope("prototype")
  public WebClient.Builder createExternalBuilder(
      @Qualifier("defaultWebClientConfig") String webClientConfigName) {
    return createDefaultBuilder(getWebClientConfigProperties(webClientConfigName));
  }

  private CoreWebClientProperties getWebClientConfigProperties(String webClientConfigName) {
    return Optional.ofNullable(coreWebClientConnectionProperties.getProperties())
        .map(
            properties ->
                properties.getOrDefault(webClientConfigName, createDefaultWebClientConfig()))
        .orElse(createDefaultWebClientConfig());
  }

  private WebClient.Builder createDefaultBuilder(CoreWebClientProperties properties) {
    HttpClient httpClient =
        HttpClient.create(createConnectionProvider(properties))
            .doOnConnected(
                connection ->
                    connection.addHandlerLast(
                        new WriteTimeoutHandler(
                            properties.getWriteTimeoutMilli(), TimeUnit.MILLISECONDS)))
            .doOnConnected(
                connection ->
                    connection.addHandlerLast(
                        new ReadTimeoutHandler(
                            properties.getReadTimeoutMilli(), TimeUnit.MILLISECONDS)))
            .doOnRequest(
                (httpRequest, connection) ->
                    connection.addHandlerFirst(new CustomLogger(HttpClient.class)))
            .wiretap(properties.isLoggingEnabled())
            .compress(properties.isCompressionEnabled());
    return WebClient.builder()
        .clientConnector(new ReactorClientHttpConnector(httpClient))
        .filter(new CoreWebClientRequestResponseLogger(properties.isLoggingEnabled()));
  }

  protected static ConnectionProvider createConnectionProvider(
      CoreWebClientProperties coreWebClientProperties) {
    Integer maxConnectionsLocal =
        Optional.ofNullable(coreWebClientProperties.getMaxConnectionPoolSize())
            .filter(i -> i > -1)
            .orElse(ConnectionProvider.DEFAULT_POOL_MAX_CONNECTIONS);
    return ConnectionProvider.builder(coreWebClientProperties.getConnectionPoolName())
        .maxConnections(maxConnectionsLocal)
        .metrics(true)
        .build();
  }

  public static class CustomLogger extends LoggingHandler {
    public CustomLogger(Class<?> clazz) {
      super(clazz);
    }

    @Override
    protected String format(ChannelHandlerContext ctx, String event, Object arg) {
      if (arg instanceof ByteBuf) {
        ByteBuf msg = (ByteBuf) arg;
        return msg.toString(CharsetUtil.UTF_8);
      }
      return super.format(ctx, event, arg);
    }
  }
}
