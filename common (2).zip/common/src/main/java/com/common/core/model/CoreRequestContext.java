package com.common.core.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Getter
@Setter
@Builder
public class CoreRequestContext {

  private String country;
  private String locale;
  private String userId;
  private String sessionId;
  private String authStatus;
  private String channel;
  private String device;
  private String storeId;
  private String deliveryMethod;
  private String associateId;
  private String deviceCharacteristics;
  private String loyaltyMemberId;
  private String loyaltyMemberStatus;
  private String trueClientIp;

  @Builder.Default private Map<String, Object> additionalProperties = new ConcurrentHashMap<>();
}
