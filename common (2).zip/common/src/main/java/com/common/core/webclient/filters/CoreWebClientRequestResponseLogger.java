package com.common.core.webclient.filters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import reactor.core.publisher.Mono;

/**
 * Reactive request filter to log HTTP request and response details of the outgoing WebClient
 * request.
 */
public class CoreWebClientRequestResponseLogger implements ExchangeFilterFunction {

  private static final Logger log =
      LoggerFactory.getLogger(CoreWebClientRequestResponseLogger.class);

  private final boolean loggingEnabled;

  public CoreWebClientRequestResponseLogger(boolean loggingEnabled) {
    this.loggingEnabled = loggingEnabled;
  }

  @Override
  public Mono<ClientResponse> filter(
      ClientRequest clientRequest, ExchangeFunction exchangeFunction) {
    if (loggingEnabled) {
      log.info(
          "Request: method={}, url={}, queryString={}, headers={}",
          clientRequest.method(),
          clientRequest.url(),
          clientRequest.url().getQuery(),
          clientRequest.headers());
    }

    return exchangeFunction
        .exchange(clientRequest)
        .doOnSuccess(
            clientResponse ->
                log.info(
                    "Response: url={}, headers={}, status={}",
                    clientRequest.url(),
                    clientResponse.headers().asHttpHeaders(),
                    clientResponse.statusCode()))
        .doOnError(throwable -> log.info("Response: url={}, status={}, ", clientRequest.url(), 500))
        .doOnError(throwable -> log.error("Error: ", throwable));
  }
}
