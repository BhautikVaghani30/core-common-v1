package com.common.core.webclient.filters;

import com.common.core.constant.CoreCommonConstants;
import com.common.core.enums.CoreHeaderKeys;
import com.common.core.enums.CoreQueryParamKeys;

import com.common.core.model.CoreRequestContext;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.util.Optional;

public class CoreRequestContextToQueryParamExchange implements ExchangeFilterFunction {

  /**
   * Reactive request filter to propagate ULTA context query parameters headers from reactive
   * context to the outgoing WebClient request.
   */
  @Override
  public Mono<ClientResponse> filter(
      ClientRequest clientRequest, ExchangeFunction exchangeFunction) {
    return Mono.deferContextual(Mono::just)
        .flatMap(
            context -> {
              Optional<CoreRequestContext> requestContext =
                  context.getOrEmpty(CoreCommonConstants.REQUEST_CONTEXT_NAME);
              ClientRequest newRequest =
                  requestContext
                      .map(
                          reqContext -> {
                            if (reqContext != null) {
                              return ClientRequest.from(clientRequest)
                                  .headers(
                                      httpHeaders -> {
                                        httpHeaders.remove(
                                            CoreHeaderKeys.X_ULTA_COUNTRY.getValue());
                                        httpHeaders.remove(CoreHeaderKeys.X_ULTA_LOCALE.getValue());
                                        httpHeaders.remove(
                                            CoreHeaderKeys.X_ULTA_CHANNEL.getValue());
                                        httpHeaders.remove(CoreHeaderKeys.X_ULTA_DEVICE.getValue());
                                        httpHeaders.remove(
                                            CoreHeaderKeys.X_ULTA_ASSOCIATE_ID.getValue());
                                        httpHeaders.remove(
                                            CoreHeaderKeys.X_ULTA_STORE_ID.getValue());
                                        httpHeaders.remove(
                                            CoreHeaderKeys.X_ULTA_TRUE_CLIENT_IP.getValue());
                                        httpHeaders.remove(
                                            CoreHeaderKeys.X_AKAMAI_DEVICE_CHARACTERISTICS
                                                .getValue());
                                      })
                                  .url(
                                      UriComponentsBuilder.fromUri(clientRequest.url())
                                          .queryParam(
                                              CoreQueryParamKeys.X_ULTA_COUNTRY.getValue(),
                                              reqContext.getCountry())
                                          .queryParam(
                                              CoreQueryParamKeys.X_ULTA_LOCALE.getValue(),
                                              Optional.ofNullable(reqContext.getLocale())
                                                  .map(
                                                      locale ->
                                                          locale
                                                              .toLowerCase()
                                                              .replace(" ", "-")
                                                              .replace("_", "-"))
                                                  .orElse(null))
                                          .queryParam(
                                              CoreQueryParamKeys.X_ULTA_CHANNEL.getValue(),
                                              Optional.ofNullable(reqContext.getChannel()))
                                          .queryParam(
                                              CoreQueryParamKeys.X_ULTA_DEVICE.getValue(),
                                              Optional.ofNullable(reqContext.getDevice()))
                                          .queryParam(
                                              CoreQueryParamKeys.X_ULTA_STORE_ID.getValue(),
                                              Optional.ofNullable(reqContext.getStoreId()))
                                          .queryParam(
                                              CoreQueryParamKeys.X_ULTA_ASSOCIATE_ID.getValue(),
                                              Optional.ofNullable(reqContext.getAssociateId()))
                                          .queryParam(
                                              CoreQueryParamKeys.X_ULTA_TRUE_CLIENT_IP.getValue(),
                                              Optional.ofNullable(reqContext.getTrueClientIp()))
                                          .queryParam(
                                              CoreQueryParamKeys.X_AKAMAI_DEVICE_CHARACTERISTICS
                                                  .getValue(),
                                              Optional.ofNullable(
                                                  reqContext.getDeviceCharacteristics()))
                                          .build()
                                          .toUri())
                                  .build();
                            }
                            return clientRequest;
                          })
                      .orElse(clientRequest);
              return exchangeFunction.exchange(newRequest);
            });
  }
}
