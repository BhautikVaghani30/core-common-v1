package com.common.core.model;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Use below pattern to set the webclient config properties for "promotion" client
 *
 * <p>ulta.webclient.properties.promotion.maxConnectionPoolSize=100
 *
 * <p>for "price" client
 *
 * <p>ulta.webclient.properties.price.maxConnectionPoolSize=200
 */
@ConfigurationProperties(prefix = "ulta.webclient")
@Getter
@Setter
@Component
public class CoreWebClientConnectionProperties {
  private Map<String, CoreWebClientProperties> properties;
}
