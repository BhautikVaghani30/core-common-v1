package com.common.core.context;

import com.common.core.model.CoreRequestContext;

public final class CoreContext {
  /**
   * The adapter responsible for managing the current CoreRequestContext.
   * This is initialized once and used throughout the application to access and manipulate the context.
   */
  private static final CoreRequestContextAdapter CORE_REQUEST_CONTEXT_ADAPTER =
      new CoreRequestContextAdapter();

  /**
   * Error message for when the adapter is unexpectedly null.
   * While the current implementation initializes it statically, this provides a safeguard
   * for potential future refactorings or unexpected class loading issues.
   */
  private static final String ADAPTER_NOT_NULL = "UltaRequestContextAdapter cannot be null.";

  /**
   * Private constructor to prevent instantiation of this utility class.
   * All methods are static and operate on a shared context.
   */
  public CoreContext() {}

  /**
   * Retrieves the current CoreRequestContext associated with the current thread of execution.
   *
   * @return The current CoreRequestContext.
   * @throws IllegalStateException if the CORE_REQUEST_CONTEXT_ADAPTER is null,
   *     indicating a critical initialization failure.
   */
  public static CoreRequestContext getContext() {
    if (CORE_REQUEST_CONTEXT_ADAPTER == null) {
      throw new IllegalStateException(ADAPTER_NOT_NULL);
    }
    return CORE_REQUEST_CONTEXT_ADAPTER.getCurrentContext();
  }
  /**
   * Clears the current CoreRequestContext, effectively removing any context associated
   * with the current thread. This is typically called at the end of a request or operation
   * to prevent context leakage.
   *
   * @throws IllegalStateException if the CORE_REQUEST_CONTEXT_ADAPTER is null,
   *     indicating a critical initialization failure.
   */
  public static void clear() {
    if (CORE_REQUEST_CONTEXT_ADAPTER == null) {
      throw new IllegalStateException(ADAPTER_NOT_NULL);
    }
    CORE_REQUEST_CONTEXT_ADAPTER.clear();
  }
  /**
   * Sets the CoreRequestContext for the current thread of execution.
   * This method is used to establish the context at the beginning of a request or operation.
   *
   * @param coreRequestContext The CoreRequestContext to be set.
   * @throws IllegalStateException if the CORE_REQUEST_CONTEXT_ADAPTER is null,
   *     indicating a critical initialization failure.
   */
  public static void setContext(CoreRequestContext coreRequestContext) {
    if (CORE_REQUEST_CONTEXT_ADAPTER == null) {
      throw new IllegalStateException(ADAPTER_NOT_NULL);
    }
    CORE_REQUEST_CONTEXT_ADAPTER.setContext(coreRequestContext);
  }
  /**
   * Returns the underlying CoreRequestContextAdapter.
   * This method is primarily for internal use or for advanced scenarios where direct
   * interaction with the adapter is necessary.
   *
   * @return The CoreRequestContextAdapter instance.
   */
  public static CoreRequestContextAdapter getRequestContextAdapter() {
    return CORE_REQUEST_CONTEXT_ADAPTER;
  }
}
