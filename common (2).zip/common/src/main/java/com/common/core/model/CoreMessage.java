package com.common.core.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a data transfer object for a single message.
 *
 * <p>This class is used to encapsulate message details, such as its type and a unique code.
 * It is designed to be a simple and flexible container for message information.
 */
@Setter
@Getter
@ToString
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CoreMessage {
  /**
   * The type of the message, indicating its nature (e.g., info, error, warning).
   */
  private String type;
  /**
   * A unique code identifying the specific message.
   */
  private String code;

  /**
   * Enumerates the possible types of a {@link CoreMessage}.
   */
  public enum CoreMessageType {
    /**
     * Informational message.
     */
    INFO("info"),
    /**
     * Error message.
     */
    ERROR("error"),
    /**
     * Warning message.
     */
    WARNING("warning");

    /**
     * The string representation of the message type.
     */
    private final String value;
    private static final Map<String, CoreMessageType> MESSAGE_TYPE_MAP = new HashMap<>();

    CoreMessageType(String value) {
      this.value = value;
    }

    static {
      for (CoreMessageType c : values()) {
        MESSAGE_TYPE_MAP.put(c.value, c);
      }
    }
  }
}
