package com.common.core.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Represents a generic response object for core operations.
 * This class is designed to be a standardized container for API responses,
 * including metadata, the actual data payload, and any associated messages.
 *
 * @param <T> the type of the data payload
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"meta", "data", "messages"})
public class CoreResponse<T> {
    /**
     * Metadata associated with the response, such as timestamp and status.
     */
    private CoreMeta meta;
    /**
     * The main data payload of the response.
     */
    private T data;
    /**
     * A list of messages, such as errors, warnings, or informational messages.
     */
    private List<CoreMessage> messages;
}
