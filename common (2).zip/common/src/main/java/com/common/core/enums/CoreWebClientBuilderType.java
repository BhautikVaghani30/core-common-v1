package com.common.core.enums;

import com.common.core.constant.CoreWebClientBuilderTypeConstants;
import lombok.Getter;

public enum CoreWebClientBuilderType {
  CORE(CoreWebClientBuilderTypeConstants.CORE_WEB_CLIENT_BUILDER),
  ORCH(CoreWebClientBuilderTypeConstants.ORCH_WEB_CLIENT_BUILDER),
  ORCH_WITH_COMPRESSION(CoreWebClientBuilderTypeConstants.ORCH_WITH_COMPRESSION_WEB_CLIENT_BUILDER),
  EXTERNAL(CoreWebClientBuilderTypeConstants.EXTERNAL_WEB_CLIENT_BUILDER);
  @Getter private final String webClientBuilderName;

  CoreWebClientBuilderType(String webClientBuilderName) {
    this.webClientBuilderName = webClientBuilderName;
  }

  @Override
  public String toString() {
    return webClientBuilderName;
  }
}
