package com.common.core.webclient.filters;

import java.util.Map;
import java.util.Optional;

import com.common.core.constant.CoreCommonConstants;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import reactor.core.publisher.Mono;

/**
 * Reactive request filter to propagate ULTA headers from reactive context to the outgoing WebClient
 * request.
 */
public class CoreHeaderExchange implements ExchangeFilterFunction {

  @Override
  public Mono<ClientResponse> filter(
      ClientRequest clientRequest, ExchangeFunction exchangeFunction) {
    return Mono.deferContextual(Mono::just)
        .flatMap(
            context -> {
              Optional<Map<String, String>> headerMap =
                  context.getOrEmpty(CoreCommonConstants.HEADERS_CONTEXT_NAME);

              ClientRequest newRequest = clientRequest;
              if (headerMap.isPresent()) {
                newRequest =
                    ClientRequest.from(clientRequest)
                        .headers(
                            httpHeaders -> {
                              headerMap.get().forEach(httpHeaders::add);
                            })
                        .build();
              }
              return exchangeFunction.exchange(newRequest);
            })
        .switchIfEmpty(exchangeFunction.exchange(clientRequest)); // In case the context is empty
  }
}
