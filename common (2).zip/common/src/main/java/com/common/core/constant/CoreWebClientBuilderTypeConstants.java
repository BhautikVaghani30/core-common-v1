package com.common.core.constant;

public final class CoreWebClientBuilderTypeConstants {

  public static final String CORE_WEB_CLIENT_BUILDER = "coreWebClientBuilder";
  public static final String ORCH_WEB_CLIENT_BUILDER = "orchWebClientBuilder";
  public static final String ORCH_WITH_COMPRESSION_WEB_CLIENT_BUILDER =
      "orchWithCompressionWebClientBuilder";
  public static final String EXTERNAL_WEB_CLIENT_BUILDER = "externalWebClientBuilder";

  private CoreWebClientBuilderTypeConstants() {}
}
