package com.common.core.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.Instant;

/**
 * Represents metadata associated with a core operation.
 * This class includes information such as a timestamp and status,
 * providing context for the operation's execution.
 */
@Setter
@Getter
@ToString
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class CoreMeta {
  /**
   * The timestamp of the operation, defaults to the current time.
   */
  @Builder.Default private String timestamp = Instant.now().toString();
  /**
   * The status of the operation.
   */
  private String status;
}
