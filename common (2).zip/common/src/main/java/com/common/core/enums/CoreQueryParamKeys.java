package com.common.core.enums;

import lombok.Getter;

public enum CoreQueryParamKeys {
  X_ULTA_COUNTRY("country"),
  X_ULTA_LOCALE("locale"),
  X_ULTA_DELIVERY_METHOD("deliveryMethod"),
  X_ULTA_CHANNEL("channel"),
  X_ULTA_ASSOCIATE_ID("associateId"),
  X_ULTA_STORE_ID("storeId"),
  X_ULTA_DEVICE("device"),
  X_ULTA_TRUE_CLIENT_IP("trueClientIp"),
  X_AKAMAI_DEVICE_CHARACTERISTICS("deviceCharacteristics");

  CoreQueryParamKeys(String value) {
    this.value = value;
  }

  @Getter private String value;
}
