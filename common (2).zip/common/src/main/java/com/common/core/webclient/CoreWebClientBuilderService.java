package com.common.core.webclient;

import com.common.core.config.CoreWebClientBuilderConfiguration;
import com.common.core.enums.CoreWebClientBuilderType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@RequiredArgsConstructor
public class CoreWebClientBuilderService {
  private CoreWebClientBuilderFactory coreWebClientBuilderFactory;
  private CoreWebClientBuilderConfiguration coreWebClientBuilderConfiguration;

  public WebClient.Builder create(CoreWebClientBuilderType webClientType) {
    return coreWebClientBuilderFactory.getWebClientBuilder(webClientType);
  }

  public WebClient.Builder createCoreWebClient(String clientName) {
    return coreWebClientBuilderConfiguration.createCoreBuilder(clientName);
  }

  public WebClient.Builder createOrchWebClient(String clientName) {
    return coreWebClientBuilderConfiguration.createOrchestrationBuilder(clientName);
  }

  public WebClient.Builder createExternalWebClient(String clientName) {
    return coreWebClientBuilderConfiguration.createExternalBuilder(clientName);
  }

  public WebClient.Builder createOrchWithCompressionWebClient(String clientName) {
    return coreWebClientBuilderConfiguration.createOrchestrationWithCompressionBuilder(clientName);
  }
}
